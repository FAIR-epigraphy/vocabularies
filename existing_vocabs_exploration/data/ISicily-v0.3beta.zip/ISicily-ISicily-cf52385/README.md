# ISicily
I.Sicily is a project to build and maintain a TEI-XML EpiDoc corpus of the inscriptions of ancient Sicily. The public data can be accessed through a web interface at http://sicily.classics.ox.ac.uk.
More information on the project and the data can be found at http://isicily.org.
The EpiDoc files in this repository constitute the core public dataset of the project and are subject to continuous update and revision.
If you would like to contribute or collaborate on the project, please contact the repository owner, Jonathan Prag (jonathan.prag@merton.ox.ac.uk).
I.Sicily files are currently archived at irregular intervals at Zenodo: https://doi.org/10.5281/zenodo.2556743.
